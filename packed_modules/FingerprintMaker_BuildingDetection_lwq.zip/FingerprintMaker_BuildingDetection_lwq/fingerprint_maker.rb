def main(msg_from, msg, opt=:make)
  case opt
    when :make
			count, arr = msg
			#p count
			#p arr
			imgFeatureList = Java::JavaUtil::ArrayList.new()
			arr.each do |tmp_str|
				x = tmp_str.to_java_bytes
				bais = Java::JavaIo::ByteArrayInputStream.new(x)
				ois = Java::JavaIo::ObjectInputStream.new(bais)				
				y = get_class_instance 'com.example.feature.ImageFeature'
				y.setDescriptor ois.readObject()
				imgFeatureList.add(y)
			end
			#tmp_str = Base64.decode64(base64_str)
			#p tmp_str
			#data = tmp_str.to_java_bytes
			#p data.length
      #bais = Java::JavaIo::ByteArrayInputStream.new(data)
			#p bais
      #ois = Java::JavaIo::ObjectInputStream.new(bais)
			#p ois
			#impFeatureList = get_class_instance 'com.example.feature.ImageFeature'
			#p imgFeatureList
			#imgFeatureList = ois.readObject()
			#p imgFeatureList
			f = Java::JavaIo::File.new(DIC)
			#p f
			is = Java::JavaIo::FileInputStream.new(f)
			#p is
			
			@maker.setDictionary(is)
			@maker.setPicture(imgFeatureList)
			#p @maker
			puts "Making Fingerprint for picture #{count}!"			
			bof = @maker.BOFGenerator()
			#p bof
			baos = Java::JavaIo::ByteArrayOutputStream.new
			oos = Java::JavaIo::ObjectOutputStream.new(baos)
			oos.writeObject(bof)
			bytes = baos.toByteArray()
			tmp = String.from_java_bytes(bytes)

			send_to 'ImageMatcher', [count, tmp]
			#@maker.make(msg)
    when :init
			#p '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'
			@maker = get_class_instance 'com.example.feature.BagOfFeatures'
			#p @maker
    when :exit
		when :unpack
			@maker = get_class_instance 'com.example.feature.BagOfFeatures'
    else
  end
end
