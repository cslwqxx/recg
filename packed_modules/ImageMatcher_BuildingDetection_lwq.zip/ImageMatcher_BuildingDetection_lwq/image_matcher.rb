def main(msg_from, msg, opt=:match)
  case opt
    when :match
			count, tmp_str = msg
			data = tmp_str.to_java_bytes
			bais = Java::JavaIo::ByteArrayInputStream.new(data)
			ois = Java::JavaIo::ObjectInputStream.new(bais)				
			bof = ois.readObject()
			#p bof
			f = Java::JavaIo::File.new(MODEL)
			is = Java::JavaIo::FileInputStream.new(f)
			inputReader = Java::JavaIo::InputStreamReader.new(is)
			#p inputReader
			
			@matcher.setInputReader(inputReader)
			puts "Image Matching for picture #{count}!"
			ans = @matcher.objectIdentify(bof)
			send_to('Client', [count, ans])
    when :init
			#p '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'
			@matcher = get_class_instance 'com.example.imgrecg.ObjectIdentifier'
			#p @matcher
		when :pack
			return nil
		when :unpack
			@matcher = get_class_instance 'com.example.imgrecg.ObjectIdentifier'
    when :exit
    else
  end
end