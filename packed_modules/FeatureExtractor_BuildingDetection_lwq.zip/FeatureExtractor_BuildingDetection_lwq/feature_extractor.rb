def main(msg_from, msg, opt=:extract)
  case opt
    when :extract
			#p msg
			tmp_str = msg
			@count += 1
			#p @count
			#p tmp_str
			data = tmp_str.to_java_bytes
			
			#p '11111111111'
			bmp = ((RbConfig::CONFIG['host_vendor'] =~ /android/i) === nil) ? 
				Java::JavaxImageio::ImageIO.read(Java::JavaIo::ByteArrayInputStream.new(data)) :
				Java::AndroidGraphics::BitmapFactory.decodeByteArray(data, 0, data.length)
			#p bmp
			#p RbConfig::CONFIG['host_vendor']
			#p @Sift
			#puts "Extracting features from image #{@count}."
			#@Sift ||= get_class_instance 'com.example.feature.Sift'
			#p @Sift
			imgFeatureList = @Sift.getFeatures(bmp)
			puts "Finished features extraction for image #{@count}."

			
			#p baos
			
			#p oos
			arr = []
			imgFeatureList.each do |e|
				x = e.getDescriptor
				baos = Java::JavaIo::ByteArrayOutputStream.new
				oos = Java::JavaIo::ObjectOutputStream.new(baos)
				oos.writeObject(x)
				bytes = baos.toByteArray()
				tmp = String.from_java_bytes(bytes)
				arr.push(tmp)
			end
      #oos.writeObject(imgFeatureList)
      #bytes = baos.toByteArray()
			#p bytes.length
      #tmp = String.from_java_bytes(bytes)
			#puts 'Start to send features.'
			send_to 'FingerprintMaker', [@count, arr]
    when :init
			#p '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'
			@Sift = get_class_instance 'com.example.feature.Sift'
			@count = 0
			#p @Sift
		when :pack
			@count
		when :unpack
			@count = msg
			@Sift = get_class_instance 'com.example.feature.Sift'
    when :exit
    else
  end
end
