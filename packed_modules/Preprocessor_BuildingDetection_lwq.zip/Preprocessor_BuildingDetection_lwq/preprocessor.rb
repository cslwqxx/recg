def main(msg_from, msg, opt=:downscale)
  case opt
    when :downscale
			width_old, height_old, tmp_str = msg
			data = tmp_str.to_java_bytes
			width = (@compress_ratio * width_old).ceil
			height = (@compress_ratio * height_old).ceil	
			new_data = @scaler.scale(width, height, data)
			tmp = String.from_java_bytes(new_data)
			puts 'Preprocessor is sending rescaled picture!'
			send_to('FeatureExtractor', tmp)
    when :init
			@scaler = get_class_instance 'com.example.imgrecg.Scaler'
		when :unpack
			@scaler = get_class_instance 'com.example.imgrecg.Scaler'
    when :exit
    else
  end
end